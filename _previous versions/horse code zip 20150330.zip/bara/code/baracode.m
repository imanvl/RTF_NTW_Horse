function M_bara= baracode(a, M, Assets, Liabilities, E, TA, Ensemble)
u = Assets;
v = Liabilities';
M_bara=hybrid_fct3(1,u,v);
