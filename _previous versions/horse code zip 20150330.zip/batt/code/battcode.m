function M_batt = battcode(a, M, Assets, Liabilities, E, TA, Ensemble)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: This script reconstructs network ensembles using information
%              about node attributes, using fitness modeling.
%              The networks estimation is performed at each time snapshot
%              provided in the input folder. See readme.txt for the details.
%
% Workflow: 1) Parameters to be set:
%                              i. number of estimated networks for each snapshot
%                              ii. desired density of the network
%                              iii. initialization of the vector of z solutions
%
%           2) Import data
%           3) Estimate networks for each snapshot
%           4) Export adjancency matrices and csv edgelists with estimated
%              networks in subfolders.
%
% Author: Stefano Gurciullo
%         s.gurciullo@cs.ucl.ac.uk
%
% Last modified: 23/03/2015
%
%
% Version 1.1


%no. of nets for each ensemble
nNetworks = Ensemble;

%number of banks
nNodes = length(M);

%vector containing potential solutions for z
z_vec = linspace(105000, 150000, 1000);

% interbank assets
IBassets = Assets + 1;

% interbank liabilities
IBliabilities = Liabilities + 1;


%% find z

%input density: must set at twice the actual density
k_sum = 2 * nnz(M)/(length(Assets) * (length(Assets) - 1));

%initialise fitness
%NOTE: fitness can be any quantity desired, here is our take
fitness = TA/sum(TA);

IBAssets_frac = IBassets/sum(IBassets);
IBLiab_frac =  IBliabilities/sum(IBliabilities);

%initiliaze z solutions vector
[z, P] = f_bootstrap_z(nNodes, k_sum, fitness, z_vec);

%% Evaluate networks for the ensemble
sum_k = zeros(1,nNetworks);

t = 1;
for n = 1:nNetworks
    
    %creat adjacency matrix
    [adj, sum_k(n)] = f_bootstrap_ensembles(nNodes, P);
    
    %assign weights
    [adj, actual_sum_rows, actual_sum_cols, diff, diff_r] = ...
        f_bootstrap_weights2(adj,IBAssets_frac, IBLiab_frac, IBassets',...
        IBliabilities);
    
    [row, col, v] = find(adj);
    estimatedInterbank_mat = full(sparse(row, col, v));
    if size(estimatedInterbank_mat) == size(M)
        M_batt(:,:,t) = estimatedInterbank_mat;
        t = t+1;
    end
    
end


