function Elist = f_mat2adj(E)

%% find indices of nonzero elements
[row, col] = find(E);

