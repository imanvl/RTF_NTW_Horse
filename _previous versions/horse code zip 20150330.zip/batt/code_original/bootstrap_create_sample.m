function [net_adj_list, net_node_attr, net_edge_attr] = bootstrap_create_sample()
% Create sample data
% Inputs: 
% Outputs

%% Initialiase variables

n_banks = 20;


