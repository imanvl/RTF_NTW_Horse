labels=1:1:rows;
labels=labels';

approachesList2 = {'orig','anan','bara','hala','maxe'};
for a = approachesList2
    
    technique = a{:};
    
    % Compare the ordering of debtRank importance
    outputMatrices.(technique).rank = horzcat(outputMatrices.(technique).debtrank,labels);
    outputMatrices.(technique).rank = sortrows(outputMatrices.(technique).rank,-1);
    outputMatrices.(technique).top1 = ismember(outputMatrices.orig.rank(1,2),outputMatrices.(technique).rank(1,2));
    outputMatrices.(technique).top3 = ismember(outputMatrices.orig.rank(1,2),outputMatrices.(technique).rank(1:3,2));
    outputMatrices.(technique).corr = corr(outputMatrices.orig.debtrank,outputMatrices.(technique).debtrank);
    outputMatrices.(technique).overlap1 = length(intersect(outputMatrices.orig.rank(1,2),outputMatrices.(technique).rank(1,2))) / ...
        length(union(outputMatrices.orig.rank(1,2),outputMatrices.(technique).rank(1,2)));
    outputMatrices.(technique).overlap3 = length(intersect(outputMatrices.orig.rank(1:3,2),outputMatrices.(technique).rank(1:3,2))) / ...
        length(union(outputMatrices.orig.rank(1:3,2),outputMatrices.(technique).rank(1:3,2)));
        
    % Compute generated loss (DebtRank)
    DR=outputMatrices.(technique).debtrank;                 % obtain DR vector
    ib_assets=nansum(outputMatrices.(technique).Network,2); % obtain interbank assets
    DR_loss=zeros(length(DR),1);                            %initialize output
    for k=1:length(DR)
        DR_loss(k)= DR(k)* (sum(ib_assets)- ib_assets(k));  %calculate DR loss excluding own assets
    end
    outputMatrices.(technique).debtrankloss = DR_loss*10^(nOrder-2); %rescale losses to original (is this okay??)
       
end


approachesList3 = {'batt','dreh','mast2'};
for a = approachesList3
    
    technique = a{:};
    
    ensembleN = size(outputMatrices.(technique).Network,3);
    
    for e = 1 : ensembleN
        
        % Compare the ordering of debtRank importance
        outputMatrices.(technique).rank(:,:,e) = horzcat(outputMatrices.(technique).debtrank(:,e),labels);
        outputMatrices.(technique).rank(:,:,e) = sortrows(outputMatrices.(technique).rank(:,:,e),-1);
        outputMatrices.(technique).top1(e) = ismember(outputMatrices.orig.rank(1,2),outputMatrices.(technique).rank(1,2,e));
        outputMatrices.(technique).top3(e) = ismember(outputMatrices.orig.rank(1,2),outputMatrices.(technique).rank(1:3,2,e));
        outputMatrices.(technique).corr(e) = corr(outputMatrices.orig.debtrank,outputMatrices.(technique).debtrank(:,e));
        outputMatrices.(technique).overlap1(e) = length(intersect(outputMatrices.orig.rank(1,2),outputMatrices.(technique).rank(1,2,e))) / ...
            length(union(outputMatrices.orig.rank(1,2),outputMatrices.(technique).rank(1,2,e)));
        outputMatrices.(technique).overlap3(e) = length(intersect(outputMatrices.orig.rank(1:3,2),outputMatrices.(technique).rank(1:3,2,e))) / ...
            length(union(outputMatrices.orig.rank(1:3,2),outputMatrices.(technique).rank(1:3,2,e)));
        

        % Compute generated loss (DebtRank)
        DR=outputMatrices.(technique).debtrank(:,e);                   % obtain DR vector
        ib_assets=nansum(outputMatrices.(technique).Network(:,:,e),2); % obtain interbank assets
        DR_loss=zeros(length(DR),1);                                   % initialize output
        for k=1:length(DR)
            DR_loss(k)= DR(k)* (sum(ib_assets)- ib_assets(k));         % calculate DR loss excluding own assets
        end
        outputMatrices.(technique).debtrankloss(:,e) = DR_loss*10^(nOrder-2); %rescale losses to original (is this okay??)
    end
end

clear('DR','ib_assets','DR_loss');
clear('ensembleN','approachesList3','approachesList2','a','technique','e');
