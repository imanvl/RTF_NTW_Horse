global rozm_pom;
global PI_mat;
global P_hat;
global PROG_BANKRUCTWA;
global WYM_KAP;
global DEF_PRZEZ_MIEDZYB;
global LIQ_DELTA; %\in(0,1)
global HAIRCUT;
global GDZIE_HAIRCUT_50PROC;

DEF_PRZEZ_MIEDZYB = 1;
GDZIE_HAIRCUT_50PROC = log(1000000000000);
LIQ_DELTA = 0.8;
HAIRCUT = 0.0;
PROG_BANKRUCTWA = 0;
%Rozmiar = rozm_pom;
