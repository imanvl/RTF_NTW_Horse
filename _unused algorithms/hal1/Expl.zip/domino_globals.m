global Rozmiar;

%Rozmiar = size of the network
Rozmiar = 5;
