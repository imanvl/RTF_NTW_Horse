##Created by GRZEGORZ HALAJ based on:
#Grzegorz Ha{\l}aj and Christoffer Kok (2013) "Modeling emergence of the interbank networks", ECB WP 1646

#import sys
#sys.path.append("D:\Doc\Python\lib\site-packages\cvxopt")
##execfile("D:\\Doc\\InterbankContagion\\python\\RTF\\appIBank_RTF.py")

import csv
import math
import time
import random
import numpy
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import matplotlib.cm as cmx
import networkx as nx
from Tkinter import *
import scipy.stats as spstat
    
class Banks:
  def __init__(self,nb,n,ta,loans,sec,iamax,depo,wf,ilmax,db,e,ei,xx,yy,bname,shortbname,cds,lgd,bsp):
    self.nBanks = nb #number of banks in the system

    self.SETSEEDDBS = 0 #1: setting seed of randomness to int(10) to get full comparability
    self.SETSEEDVALUEDBS = random.randint(0,10**6)

    self.BIGNUMBER = 1000000.0

    self.PATHINPUTDATA = 'D:\\Doc\\InterbankContagion\\python\\RTF\\' #CHANGE PATH TO YOUR FOLDER WITH INPUT DATA!!!!!
    #self.PATHINPUTDATA = '/home/ghalaj/Documents/BW2013/EndogNets/EndogNetsSeq/python/' #Linux path
    
    self.LExpLimitIndivRatio = 0.25
    self.LExpLimitAggrRatio = 0.10
    self.LExpLimitAggrRatioRule = 8.00

    self.rw_ia_b = 0.2 #risk weight of the interbank exposure

    self.cprties_list = numpy.array([],dtype=int) #for endog nets generator: the identifying numbers of banks with close relationship with self (counterparties, therefore cprties_list)
    self.fndprvd_list = numpy.array([],dtype=int) #for endog nets generator: the identifying numbers of banks providing (prvd) funding (fnd)
    
    #ta: total assets
    #loans: loan categories (any length)
    #sec: securities (bonds) (of any length)
    #iamax: maximal sum of interbank exposures that can still be assigned
    #depo: deposits from customers (retail) (any length)
    #wf: non-financial other deposits (large corp) (any length)
    #ilmax: maximal sum of interbank deposits that can still be assigned
    #db: debt issued (any length)
    #e: capital
    self.ta = ta
    self.ll = loans
    self.ss = sec
    self.iamax = iamax
    self.dd = depo
    self.wf = wf
    self.ilmax = ilmax
    self.db = db
    self.ee = float(e)
    self.ei = float(ei)

    self.iamax_ua = iamax #unallocated interbank assets (for endog nets)
    self.ilmax_ua = ilmax #unallocated interbank liabilities (for endog nets)
    self.ei_ua = self.ei #unallocated capital related to the interbank risks (for endog nets)
    
    #ia: interbank loans to all counterparts in the market
    self.ia = [0.0]*self.nBanks
    #il: interbank deposits to all counterparts in the market
    self.il = [0.0]*self.nBanks
    
    #(RATIO) large exposure limit ratio: individual exposure to capital
    self.lexp_indv = 0.0
    #(SUM) large exposure limit ration: aggregate exposure (each of which exceeding 10% ee)  
    self.lexp_aggr_sum = 0.0
    
    #credit quality
    self.cds = cds #in bps
    self.lgd = lgd #no units, i.e. 45% lgd means self.lgd=0.045
    
    self.numberBank = n
    self.name = bname
    self.sname = shortbname

    ######!!!part used for a dynamic balance sheet optimisation model - not included!!!!    
    ##FOR DYN BS
    self.NSIM_PI_DBS = 400
    self.NMONTECARLO = 1000
    
    self.IFPOLYFITOFVALUEF = 0.0 #1: polynomial fitting of the value function outcome - variance reductions technique
    self.POLYFITDEG = 4

    self.IFGRAPH = 1

    self.NORM_SAMPLE = numpy.zeros((self.NMONTECARLO,3))

    self.l_dbs = self.ll
    self.s_dbs = self.ss
    self.f_dbs = self.dd
    self.fmin1_dbs = self.dd

    self.m_dbs = bsp[0] # maturity
    self.r_dbs = bsp[1] # interest rate
    self.rF_dbs = bsp[2] # interest rate paid to funding sources
    self.h_dbs = bsp[3] # haicut on sec
    self.g_dbs = bsp[4] # gamma param of funding
    self.kappa_dbs = bsp[5] # CAR limit (normally 0.08)
    self.aF_dbs = bsp[6] # alpha parameter of liquidity VaR constraint
    self.beta_dbs = bsp[7] # risk aversion
    self.rwa_l_dbs = bsp[8] # risk weight of loans
    self.rwa_s_dbs = bsp[9] # risk weight of sec
    self.delta_dbs = bsp[10] # discount factor
    self.r_penalty_dbs = bsp[11] # loss at default (rate)
    self.lgd_dbs = bsp[12] # average loss given default on loans
    
    #risk return params:
    self.mu_eps_dbs = bsp[13] # mu of epsilon
    self.sg_eps_dbs = bsp[14] # sigma of epsilon
    self.mu_rho_dbs = bsp[15] # mu of rho
    self.sg_rho_dbs = bsp[16] # sigma of rho
    self.mu_rhN_dbs = bsp[17] # mu of rho N
    self.sg_rhN_dbs = bsp[18] # sigma of rho N    
    self.mu_eta_dbs = bsp[19] # mu of eta
    self.sg_eta_dbs = bsp[20] # sigma of eta
    self.cor_er_dbs = bsp[21] # correlation between epsilon and rho
    self.cor_eN_dbs = bsp[22] # correlation between epsilon and rho N
    self.cor_ee_dbs = bsp[23] # correlation between epsilon and eta
    self.cor_rN_dbs = bsp[24] # correlation between rho and rho N
    self.cor_re_dbs = bsp[25] # correlation between rho and eta
    self.cor_Ne_dbs = bsp[26] # correlation between rho N and eta

    self.mean_dbs = [self.mu_eps_dbs,self.mu_rho_dbs,self.mu_rhN_dbs,self.mu_eta_dbs]

    #covariance
    self.cov_dbs = [[self.sg_eps_dbs**2,self.cor_er_dbs*self.sg_eps_dbs*self.sg_rho_dbs,self.cor_eN_dbs*self.sg_eps_dbs*self.sg_rhN_dbs,self.cor_ee_dbs*self.sg_eps_dbs*self.sg_eta_dbs],[self.cor_er_dbs*self.sg_eps_dbs*self.sg_rho_dbs,self.sg_rho_dbs**2,self.cor_rN_dbs*self.sg_rho_dbs*self.sg_rhN_dbs,self.cor_re_dbs*self.sg_rho_dbs*self.sg_eta_dbs],
[self.cor_eN_dbs*self.sg_eps_dbs*self.sg_rhN_dbs,self.cor_rN_dbs*self.sg_rho_dbs*self.sg_rhN_dbs,self.sg_rhN_dbs**2,self.cor_Ne_dbs*self.sg_rhN_dbs*self.sg_eta_dbs],
[self.cor_ee_dbs*self.sg_eps_dbs*self.sg_eta_dbs,self.cor_re_dbs*self.sg_rho_dbs*self.sg_eta_dbs,self.cor_Ne_dbs*self.sg_rhN_dbs*self.sg_eta_dbs,self.sg_eta_dbs**2]]

    self.inv_aF = spstat.norm.ppf(self.aF_dbs) # percentile corresponding to self.aF_dbf

    #END OF: !!!part used for a dynamic balance sheet optimisation model - not included!!!!

    #graphical parameters
    self.xx = xx #x coordinate
    self.yy = yy #y coordinate
    
  def __eq__(self,othbank):
    return self.numberBank==othbank.numberBank

  def mFRange(self, x, y, jump):
    ll = list()
    while x < y:
      ll.append(x)
      x += jump
    return ll
    
  def mChangeCDS(self,chCDS):
    #returning delta PD in bps
    cds_aux = self.cds
    self.cds+=chCDS
    
    #returning delta of pd
    return chCDS/self.lgd

  def erfcc(self,x):
    """Complementary error function."""
    z = abs(x)
    t = 1. / (1. + 0.5*z)
    r = t * numpy.exp(-z*z-1.26551223+t*(1.00002368+t*(.37409196+
      t*(.09678418+t*(-.18628806+t*(.27886807+
      t*(-1.13520398+t*(1.48851587+t*(-.82215223+
      t*.17087277)))))))))
    if (x >= 0.):
      return r
    else:
      return 2. - r

  def ncdf(self,x):
    return 1. - 0.5*self.erfcc(x/(2**0.5))

  def mSaveMat2File(self,fpath,x):
    resfile = open(fpath,'w')
    writeit = csv.writer(resfile,delimiter=',')
    for row in x:
      writeit.writerow(row)
    resfile.close()

  def mIncreaseCprtiesCircle(self,nm,me):
    #adding new members (nm) to the list
    self.cprties_list = numpy.setdiff1d(numpy.union1d(self.cprties_list,nm),me)
    return self.cprties_list

  def mIncreaseFndPrvdCircle(self,nm,me):
    #adding new members (nm) to the list
    self.fndprvd_list = numpy.setdiff1d(numpy.union1d(self.fndprvd_list,nm),me)
    return self.fndprvd_list
  
  def mLendIBank(self,bankCounterpart,rand): #bankCounterpart is another bank in the system; rand = rand number from [0,1]
    #random part to be assigned
    
    if self!=bankCounterpart and self.iamax>0 and bankCounterpart.ilmax>0:
    
      bankCounterpartNum = bankCounterpart.numberBank
    
      interbankPlacement = min(rand*self.iamax,bankCounterpart.ilmax) 
    
      self.iamax = self.iamax - interbankPlacement    
      
      bankCounterpart.iamax = bankCounterpart.iamax - interbankPlacement    
      
      self.ia[bankCounterpartNum-1] = self.ia[bankCounterpartNum-1] + interbankPlacement
      
      bankCounterpart.il[self.numberBank-1] = bankCounterpart.il[self.numberBank-1] + interbankPlacement
  
  def mLendIBankLExp(self,bankCounterpart,rand): #bankCounterpart is another bank in the system; rand = rand number from [0,1]
    #random part to be assigned
    
    if self!=bankCounterpart and self.iamax>0 and bankCounterpart.ilmax>0:
      interbankPlacement = min(rand*self.iamax,bankCounterpart.ilmax)
      
      bankCounterpartNum = bankCounterpart.numberBank
      
      lexp_ind_aux = (self.ia[bankCounterpartNum-1]+interbankPlacement)/self.ee
      lexp_aggr_aux = self.lexp_aggr_sum
      
      if interbankPlacement>self.LExpLimitAggrRatio*self.ee:
        lexp_aggr_aux+=interbankPlacement
      
      if lexp_ind_aux<=self.LExpLimitIndivRatio and lexp_aggr_aux<=self.LExpLimitAggrRatioRule*self.ee:
        self.iamax = self.iamax - interbankPlacement    
      
        bankCounterpart.iamax = bankCounterpart.iamax - interbankPlacement    
      
        self.ia[bankCounterpartNum-1] = self.ia[bankCounterpartNum-1] + interbankPlacement
      
        bankCounterpart.il[self.numberBank-1] = bankCounterpart.il[self.numberBank-1] + interbankPlacement
      
        self.lexp_aggr_sum=lexp_aggr_aux

  def mGenFactorsDBS(self):
    if self.SETSEEDDBS==1:
      numpy.random.seed(10)
    else:
      numpy.random.seed(self.SETSEEDVALUEDBS)

    #update: mean
    self.mean_dbs = [self.mu_eps_dbs,self.mu_rho_dbs,self.mu_rhN_dbs,self.mu_eta_dbs]
    
    #update: covariance
    self.cov_dbs = [[self.sg_eps_dbs**2,self.cor_er_dbs*self.sg_eps_dbs*self.sg_rho_dbs,self.cor_eN_dbs*self.sg_eps_dbs*self.sg_rhN_dbs,self.cor_ee_dbs*self.sg_eps_dbs*self.sg_eta_dbs],[self.cor_er_dbs*self.sg_eps_dbs*self.sg_rho_dbs,self.sg_rho_dbs**2,self.cor_rN_dbs*self.sg_rho_dbs*self.sg_rhN_dbs,self.cor_re_dbs*self.sg_rho_dbs*self.sg_eta_dbs],
[self.cor_eN_dbs*self.sg_eps_dbs*self.sg_rhN_dbs,self.cor_rN_dbs*self.sg_rho_dbs*self.sg_rhN_dbs,self.sg_rhN_dbs**2,self.cor_Ne_dbs*self.sg_rhN_dbs*self.sg_eta_dbs],
[self.cor_ee_dbs*self.sg_eps_dbs*self.sg_eta_dbs,self.cor_re_dbs*self.sg_rho_dbs*self.sg_eta_dbs,self.cor_Ne_dbs*self.sg_rhN_dbs*self.sg_eta_dbs,self.sg_eta_dbs**2]]

    
    self.NORM_SAMPLE = numpy.random.multivariate_normal(self.mean_dbs,self.cov_dbs,self.NMONTECARLO)
    
    return self.NORM_SAMPLE

  def mPrintU(self,xpi,xk,xl,xs,xf,xfmin1):
    raux = self.mu_eps_dbs
    step = 0.00
    step2 = 5.00
    for ii in range(0,30):
      print(self.mUtil_dbs(xpi+ii*step2,xk,xl,xs,xf,xfmin1))
      self.mu_eps_dbs+=step

    self.mu_eps_dbs = raux


#### INTERBANK CLASS ####
class InterBank:
  JustMoreThanZero = 0.000001 #some zeros are increased to avoid division by 0
  ClearingMaxIter = 20
  ClearingPrecision = 0.0001 # in relative (norm) sense
  BGUTILPRECISION = 0.01
  BGPRECISION = 0.001 #assuming exposures to be of size around 10^6
  ADJPRECISION = 0.1
  NumSimIBankBase = 10000 # the number of simulations of the linkages between banks

  STEPIFCVXOPTERROR = 0.2

  THRESHOLDREALISEDLIABS = 0.95

  BROADENINGMARKETEACHTIME = 2 #MAX value: 5; used in method: mFormulateIBAssetPreferredStr(self)

  CVAACTIVATED = int(0)
  CVAFACTOR = 0.0 #multiplier of the estimated cva coefficients

  STOPTHESIMTHR = 0.01 #percent of unallocated assets or liabilities for each bank
  
  RandSeed = [numpy.random.randint(0,100)/100.0 for r in range(NumSimIBankBase)]
  
  #listBanks - banks with balance sheet characterisation
  #pathrisks - interbank interest rates, CDS spreads, collelation for rates and defaults
  def __init__(self,listBanks):
    from cvxopt import matrix

    self.RANDSEED = numpy.random.randint(10**6)
    
    self.PATHINPUTDATA = 'D:\\Doc\\InterbankContagion\\python\\RTF\\'
    #self.PATHINPUTDATA = '/home/ghalaj/Documents/BW2013/EndogNets/EndogNetsSeq/python/'

    self.banks = listBanks
    
    self.nBanks = listBanks[1].nBanks

    self.LARGEEXPOSURELIMIT = [0.25]*self.nBanks

    self.GROUPFLG = int(0) # group of banks to which the regulation (LE or CVA) pertains (0: all the banks; otherwise the identification of a group by self.banks.sname)
    #current setup implies that the simulation cannot be run for CVA activated for a group of banks with LE limit different than the one defined in the initialisation of the class

    self.RW_IA = [0.2]*self.nBanks  #risk weights of the interbank assets
    
    mexp = 0
    adjMat_aux = list()
    eMat_aux = list()
    expV_aux = list()

    ii = int(0)
    for bb in self.banks:
      mexp = max(mexp,max(bb.ia))
      adjMat_aux.append(bb.ia)
      eMat_aux.append(bb.ee)
      expV_aux.append(sum(bb.ia))
      bb.rw_ia_b = self.RW_IA[ii]
    self.maxexposure = mexp
    
    self.iBankDepoMat = numpy.transpose(numpy.matrix(adjMat_aux))
    self.lossAbsCapacity = numpy.transpose(numpy.matrix(eMat_aux))
    self.iBankExposure = numpy.transpose(numpy.matrix(expV_aux)) #vector of each bank's interbank exposures

    #graphical representation
    self.position = []
    
    plt.axes()
    plt.xlim(0,100)
    plt.ylim(0,100)
    self.ax = plt.gca()
    
    #contagion
    self.p_bar = numpy.matrix([0]*self.nBanks).T
    self.p_ast = numpy.matrix([0]*self.nBanks).T

    #risks and returns (e.g. for endogenous network formation)
    self.kappa = 1.0
    self.kappa_fund = 1.0
    self.r_ia = self.mReadRisks(self.PATHINPUTDATA,'r_init.csv')
    self.sigma = self.mReadRisks(self.PATHINPUTDATA,'sigma_init.csv')
    self.sigma2 = self.mReadRisks(self.PATHINPUTDATA,'sigma2_init.csv')
    #self.Q = self.mReadRisks(self.PATHINPUTDATA,'Q_init.csv')
    self.Q2 = self.mReadRisks(self.PATHINPUTDATA,'Q2_init.csv')
    self.Q3 = self.mReadRisks(self.PATHINPUTDATA,'Q3_init.csv') #cov based only on default probabilities (for the second round of Endog Nets algorithm)
    self.pgeo = self.mReadRisks(self.PATHINPUTDATA,'pgeo.csv')
    #self.cva = self.mReadRisks(self.PATHINPUTDATA,'cva.csv')
    #self.cva = self.mReadRisks(self.PATHINPUTDATA,'cva_not_estim.csv')
    self.cva = self.mReadRisks(self.PATHINPUTDATA,'cva_zero.csv')
    self.eI = self.mReadRisks(self.PATHINPUTDATA,'eI_init.csv')

    self.pgeo_org = self.pgeo
    
    #quadratic part for the optimisation in the endogenous network problem
    self.QQ = 2.0*self.kappa*numpy.matrix(numpy.tile(self.sigma2.T,(self.nBanks,1))*numpy.matrix(self.Q2)*numpy.tile(self.sigma2,(1,self.nBanks)))
    self.RR = numpy.matrix(-self.r_ia)
    self.QQdef = 2.0*self.kappa_fund*numpy.matrix(numpy.tile(self.sigma2.T,(self.nBanks,1))*numpy.matrix(self.Q3)*numpy.tile(self.sigma2,(1,self.nBanks)))

    #preferred structures
    self.iapref_mat = numpy.zeros((self.nBanks,self.nBanks))
    self.ilpref_mat = numpy.zeros((self.nBanks,self.nBanks))

    #bargaining game
    self.bgsens_ia = numpy.ones((self.nBanks,self.nBanks)) #s^{a,k} in the paper
    self.bgsens_il = numpy.ones((self.nBanks,self.nBanks)) #s^{l,k} in the paper
    self.bgutil_ia = numpy.ones((self.nBanks,self.nBanks)) #U^{a,k\ast}
    self.bgutil_il = numpy.ones((self.nBanks,self.nBanks)) #U^{l,k\ast}

    #NON-FINANANCIAL CORPORATE SECTOR
    #??

  def mIBReset(self):
    for bb in self.banks:
      bb.iamax_ua = bb.iamax
      bb.ilmax_ua = bb.ilmax
      bb.ia = [0.0]*self.nBanks
      bb.il = [0.0]*self.nBanks
      bb.cprties_list = numpy.array([],dtype=int)
      bb.fndprvd_list = numpy.array([],dtype=int)
      bb.ei_ua = bb.ei
    
    self.iapref_mat = numpy.zeros((self.nBanks,self.nBanks))
    self.ilpref_mat = numpy.zeros((self.nBanks,self.nBanks))
    
    self.bgsens_ia = numpy.zeros((self.nBanks,self.nBanks)) #s^{a,k} as inverse of what presented in the paper (so used multiplicatively)
    self.bgsens_il = numpy.zeros((self.nBanks,self.nBanks)) #s^{l,k} in the paper
    self.bgutil_ia = numpy.ones((self.nBanks,self.nBanks)) #U^{a,k\ast}
    self.bgutil_il = numpy.ones((self.nBanks,self.nBanks)) #U^{l,k\ast}

    mexp = 0
    adjMat_aux = list()
    eMat_aux = list()
    expV_aux = list()
    for bb in self.banks:
      mexp = max(mexp,max(bb.ia))
      adjMat_aux.append(bb.ia)
      eMat_aux.append(bb.ee)
      expV_aux.append(sum(bb.ia))
    self.maxexposure = mexp
    
    self.iBankDepoMat = numpy.matrix(numpy.zeros((self.nBanks,self.nBanks)))
    self.lossAbsCapacity = numpy.transpose(numpy.matrix(eMat_aux))
    self.iBankExposure = numpy.transpose(numpy.matrix(expV_aux)) #vector of each bank's interbank exposures

    self.pgeo = self.pgeo_org

    self.CVAFACTOR = 1.0

  def mActivateCVA(self):
    self.CVAACTIVATED = int(1)
  
  def mSetLELimit(self,le):
    #REMINDER
    #self.GROUPFLG: parameter denoting banks for which the adjustment needs to be done
    #self.GROUPFLG = 0 => all
    if self.GROUPFLG==0:
      self.LARGEEXPOSURELIMIT = [le]*self.nBanks
      ii = int(0)
      for bb in self.banks:        
        bb.LExpLimitIndivRatio = le
        ii+=1
    else:
      ii = 0
      for bb in self.banks:
        #print("NAME:")
        #print(bb.sname+1.0)
        #print("Gr flag:")
        #print(self.GROUPFLG+1.0)
        if float(bb.sname)==float(self.GROUPFLG):
          self.LARGEEXPOSURELIMIT[ii]=le
          bb.LExpLimitIndivRatio = le
          #print("Group member:")
          #print(ii)
        ii+=1

  def mSetRW(self,rw):
    if self.GROUPFLG==0:
      self.RW_IA = [rw]*self.nBanks
      ii = int(0)
      for bb in self.banks:
        bb.rw_ia_b = rw
        ii+=1
    else:
      ii = int(0)
      for bb in self.banks:
        if float(bb.sname)==float(self.GROUPFLG):
          self.RW_IA[ii]=rw
          bb.rw_ia_b = rw
        ii+=1
      
  def mSetCVAFact(self,cvaf):
    self.CVAFACTOR = cvaf

  def mSetGroupflg(self,flg):
    self.GROUPFLG = flg

  def mAddPgeo(self,dpg):
    self.pgeo = self.pgeo + dpg

  def mReadRisks(self,pathf,fn):
    #fn - name of the file (csv) with an extension .csv
    ll = list()
    ll.append(pathf)
    ll.append(fn)
    xfilepath=''.join(ll)
    with open(xfilepath,'r') as net:
      datareader = csv.reader(net)
      data = []
      for row in datareader:
        l = list()
        for item in row:
          l.append(float(item))
        data.append(l)
    data = numpy.array(data)
    return data

  def mReadRisksInt(self,pathf,fn):
    #fn - name of the file (csv) with an extension .csv
    ll = list()
    ll.append(pathf)
    ll.append(fn)
    xfilepath=''.join(ll)
    with open(xfilepath,'r') as net:
      datareader = csv.reader(net)
      data = []
      for row in datareader:
        l = list()
        for item in row:
          l.append(int(item))
        data.append(l)
    data = numpy.array(data)
    return data


  def mTranslateCptriesListToFndPrvd(self):
    #translating the existing lists of counterparties into list of funding providers
    ii = int(0)
    for b in self.banks:
      for item in b.cprties_list:
        self.banks[item].mIncreaseFndPrvdCircle([ii],[])
      ii+=1
  
  def mFormulateIBAssetPreferredStr(self):
    from cvxopt import matrix
    from cvxopt import solvers
    from cvxopt.solvers import qp
    solvers.options['show_progress']=False

    xrandint = list()
    for jjj in range(0,5):
      xrandint.append(numpy.random.random_sample(size=(self.nBanks,self.nBanks)))

    ii = int(0)

    cap_aloc_tot = 0.0
    sum_tot_aloc_portf = 0.0
    well_processed_banks = list()
    ibassets_corresp_well_pr = 0.0

    #realised liabilities
    maxil = [b.ilmax for b in self.banks]
    il_ratio_diag = numpy.sum(self.iBankDepoMat,1).T/maxil
    xarr = numpy.zeros((self.nBanks,1))
    for ij in range(0,self.nBanks):
      xarr[ij,0] = il_ratio_diag[0,ij]
    bfullliabs = numpy.where(xarr>self.THRESHOLDREALISEDLIABS)[0]
    #print("full liabs:")
    #print(il_ratio_diag)
    #print(bfullliabs)

    for b in self.banks:
      #print(ii)
      #broadening the market search circle
      for kj in range(0,self.BROADENINGMARKETEACHTIME):
        xind = numpy.where(xrandint[kj][:,ii]<self.pgeo[:,ii])[0]
        newctpy=b.mIncreaseCprtiesCircle(xind,[ii])
      #subtract banks which found fully interbank funding
      newctpy=numpy.setdiff1d(newctpy,bfullliabs)
      lctpy = numpy.size(newctpy,0)
      #print("ctp1")
      #print(newctpy)
      
      if lctpy>0 and b.iamax_ua/b.iamax>self.STOPTHESIMTHR:
        #constraints
        beq_len = 1
        beq = numpy.zeros((beq_len,1))
        beq[0,0] = numpy.matrix([b.iamax_ua])
        beq = matrix(beq)

        Aeq = numpy.zeros((beq_len,lctpy))
        Aeq[0] = numpy.ones((1,lctpy))
        Aeq = matrix(Aeq)

        #if self.CVAACTIVATED == 1 and self.CVAFACTOR!=0.0:
        #  bineq_len = 2*numpy.size(newctpy,0)+2 #constraints by interbank liabilities + capital constraints
        #else:
        bineq_len = 2*numpy.size(newctpy,0)+1
          
        bineq = numpy.zeros((bineq_len,1))
        ix = 0
        for row in bineq[0:numpy.size(newctpy,0)]:
          limit_unused = max(0,self.LARGEEXPOSURELIMIT[ii]*b.ee-b.ia[newctpy[ix]])
          row[0]=min(self.banks[newctpy[ix]].ilmax_ua,limit_unused) #exposures not higher than counterparty's capacity for interbank funding and LE limits
          ix+=1
        for row in bineq[(numpy.size(newctpy,0)+1):(2*numpy.size(newctpy,0)+1)]:
          row[0]=0
          ix+=1
        bineq[ix] = b.ei_ua # capital allocated to the interbank exposures
        bineq = matrix(bineq)
        if self.CVAACTIVATED == 1 and self.CVAFACTOR!=0.0:
          bineq[ix] = b.ei_ua # a bit redundant but showing the seperate option of CVA

        cap_aloc_tot = cap_aloc_tot + b.ei_ua

        Aineq = numpy.zeros((bineq_len,lctpy))
        Aineq[0:lctpy,:] = numpy.eye(lctpy)
        Aineq[lctpy:(2*lctpy),:] = -numpy.eye(lctpy) #non-negativity of exposures
        Aineq[2*lctpy,:]=self.RW_IA[ii]*0.08*numpy.ones((1,lctpy)) #risk weights multipliers
        Aineq = matrix(Aineq)
        if self.CVAACTIVATED == 1 and self.CVAFACTOR!=0.0:
          if self.GROUPFLG==0:
            for ii in range(0,lctpy):
              Aineq[2*lctpy,ii]=Aineq[2*lctpy,ii]+self.CVAFACTOR*self.cva[newctpy[ii],0]
          else:
            if self.GROUPFLG==b.sname:
              for ii in range(0,lctpy):
                Aineq[2*lctpy,ii]=Aineq[2*lctpy,ii]+self.CVAFACTOR*self.cva[newctpy[ii],0]

        #risk return parameters
        QQ = matrix(self.QQ[numpy.ix_(newctpy.tolist(),newctpy.tolist())])
        RR = matrix(self.RR[numpy.ix_(newctpy.tolist(),[0])])
        #checks
        #print("******* bank nr:")
        #print(ii)
        #print("list of ctp:")
        #print(newctpy)
        #print("inequality constraint:")
        #print(bineq)
        #print("equality constraint:")
        #print(beq)

        ##### optimisation of interbank portfolios ####
        iaprefstr = numpy.zeros(self.nBanks)
        try:
          sol = qp(QQ,RR,Aineq,bineq,Aeq,beq)
        except ValueError, ee:
          print "error of sqrt from neg number (perhaps CVXOPT bug)"
          xerr = 1
          x_dbeq = beq[0,0]*self.STEPIFCVXOPTERROR
          while xerr == 1 and beq[0,0]>0:
            beq[0,0] = beq[0,0]-x_dbeq
            try:
              sol = qp(QQ,RR,Aineq,bineq,Aeq,beq)
            except ValueError, ee1:
              print "error of sqrt from neg number (perhaps CVXOPT bug)"
            else:
              #print("ctpy:")
              #print(newctpy)
              #print("str:")
              #print(sol['x'])
              #print("sum str:")
              #print(numpy.sum(sol['x']))
              #print("ia_max:")
              #print(b.iamax)
              #print("unalocated assets:")
              #print(b.iamax_ua)
              
              ix = 0
              for row in newctpy:
                iaprefstr[row] = numpy.maximum(0.0,sol['x'][ix])
                ix+=1
              xerr = 0
              sum_tot_aloc_portf = sum_tot_aloc_portf + max(0.0,numpy.sum(sol['x'])) #reporting
              #print("beq:")
              #print(beq)
              #print("bineq:")
              #print(bineq)
              #print("sol 1:")
              if numpy.sum(sol['x'])<-self.JustMoreThanZero:
                print("neg sol:")
                print(numpy.sum(sol['x']))
        else:
          #print(sol['x'])
          if sol['status']=='unknown':
            print("unknown")

            xunk = 1
            x_dbeq = beq[0,0]*self.STEPIFCVXOPTERROR
            while xunk == 1 and beq[0,0]>0:
              beq[0,0] = beq[0,0]-x_dbeq
              try:
                sol = qp(QQ,RR,Aineq,bineq,Aeq,beq)
              except ValueError, ee1:
                print "error of sqrt from neg number (perhaps CVXOPT bug)"
              else:
                if sol['status']=='unknown':
                  print("unknown")
                else:
                  #print("ctpy:")
                  #print(newctpy)
                  #print("str:")
                  #print(sol['x'])
                  #print("sum str:")
                  #print(numpy.sum(sol['x']))
                  #print("ia_max:")
                  #print(b.iamax)
                  #print("unalocated assets:")
                  #print(b.iamax_ua)
                  sum_tot_aloc_portf = sum_tot_aloc_portf + max(0.0,numpy.sum(sol['x']))
                  
                  ix = 0
                  for row in newctpy:
                    iaprefstr[row] = numpy.maximum(0.0,sol['x'][ix])
                    ix+=1
                  xunk = 0
                  sum_tot_aloc_portf = sum_tot_aloc_portf + max(0.0,numpy.sum(sol['x'])) #reporting
                  well_processed_banks.append(ii)
                  ibassets_corresp_well_pr = ibassets_corresp_well_pr + b.iamax_ua
                  #print("beq:")
                  #print(beq)
                  #print("bineq:")
                  #print(bineq)
                  #print("sol 2:")
                  if numpy.sum(sol['x'])<-self.JustMoreThanZero:
                    print("neg sol:")
                    print(numpy.sum(sol['x']))

          else:
            #print("ctpy:")
            #print(newctpy)
            #print("str:")
            #print(sol['x'])
            #print("sum str:")
            #print(numpy.sum(sol['x']))
            #print("ia_max:")
            #print(b.iamax)
            #print("unalocated assets:")
            #print(b.iamax_ua)
            sum_tot_aloc_portf = sum_tot_aloc_portf + max(0.0,numpy.sum(sol['x']))
            #print("beq:")
            #print(beq)
            #print("bineq:")
            #print(bineq)
            #print("sol 3:")
            if numpy.sum(sol['x'])<-self.JustMoreThanZero:
              print("neg sol:")
              print(numpy.sum(sol['x']))
            ix = 0
            for row in newctpy:
              iaprefstr[row] = numpy.maximum(0.0,sol['x'][ix])
              ix+=1

            well_processed_banks.append(ii)
            ibassets_corresp_well_pr = ibassets_corresp_well_pr + b.iamax_ua
        #print(b.iamax_ua)
        #print(sum(iaprefstr))
      else:
        iaprefstr = numpy.zeros(self.nBanks)
      
      self.iapref_mat[:,ii] = numpy.maximum(iaprefstr,0)
      
      ii+=1
    print("cap_aloc:")
    print(cap_aloc_tot)
    print("tot aloc asset portf:")
    print(sum_tot_aloc_portf)
    print("processed banks:")
    print(well_processed_banks)
    print("corresponding ib assets:")
    print(ibassets_corresp_well_pr)
    
  
  def mFormulateIBLiabPreferredStr(self):
    from cvxopt import matrix
    from cvxopt import solvers
    from cvxopt.solvers import qp
    solvers.options['show_progress']=False

    #translating counterparties
    self.mTranslateCptriesListToFndPrvd()

    xrandint = numpy.random.random_sample(size=(self.nBanks,self.nBanks))

    ii = int(0)
    for b in self.banks:
      #print(ii)
      #INCLUDED - broadening the market search circle
      xind = numpy.where(xrandint[ii,:]<self.pgeo[ii,:])[0]
      newfndp=b.mIncreaseFndPrvdCircle(xind,[ii])
      newfndp = b.fndprvd_list
      lfndp = numpy.size(newfndp,0)
      #print("fndp:")
      #print(newfndp)
      
      if lfndp>0 and b.ilmax_ua/b.ilmax>self.STOPTHESIMTHR:
        #constraints
        beq_len = 1
        beq = numpy.zeros((beq_len,1))
        beq[0,0] = numpy.matrix([b.ilmax_ua])
        beq = matrix(beq)

        Aeq = numpy.zeros((beq_len,lfndp))
        Aeq[0] = numpy.ones((1,lfndp))
        Aeq = matrix(Aeq)

        bineq_len = 2*numpy.size(newfndp,0) #constraints by interbank assets
        bineq = numpy.zeros((bineq_len,1))
        ix = 0
        for row in bineq[0:numpy.size(newfndp,0)]:
          row[0]=self.banks[newfndp[ix]].ilmax_ua #exposures not higher than counterparty's capacity for interbank funding
          ix+=1
        for row in bineq[(numpy.size(newfndp,0)+1):(2*numpy.size(newfndp,0)+1)]:
          row[0]=0
          ix+=1
        bineq = matrix(bineq)

        Aineq = numpy.zeros((bineq_len,lfndp))
        Aineq[0:lfndp] = numpy.eye(lfndp)
        Aineq[lfndp:(2*lfndp)] = -numpy.eye(lfndp) #non-negativity of exposures
        Aineq = matrix(Aineq)

        #risk return parameters
        QQdef = matrix(self.QQ[numpy.ix_(newfndp.tolist(),newfndp.tolist())])
        RR = matrix(numpy.zeros((lfndp,1)))
        #shapes
        #print(QQ.size)
        #print(RR.size)
        #print(Aineq.size)
        #print(numpy.linalg.matrix_rank(Aineq))
        #print(bineq)
        #print(Aeq.size)
        #print(numpy.linalg.matrix_rank(Aeq))
        #print(beq.size)
        #print(Aineq)

        #optimisation of interbank portfolios
        ilprefstr = numpy.zeros(self.nBanks)
        try:
          sol = qp(QQdef,RR,Aineq,bineq,Aeq,beq)
        except ValueError, ee:
          print "error of sqrt from neg number (perhaps CVXOPT bug)"
        else:
          #print(sol['x'])
          if sol['status']=='unknown':
            print("unknown")
          else:
            ix = 0
            for row in newfndp:
              ilprefstr[row] = numpy.maximum(0.0,sol['x'][ix])
              ix+=1
        #print(b.ilmax_ua)
        #print(sum(ilprefstr))
      else:
        ilprefstr = numpy.zeros(self.nBanks)
      
      self.ilpref_mat[ii,:] = numpy.maximum(0,ilprefstr)
      ii+=1

  def mbgsensTABased(self):#sensitivities in the bargaining game given by inverse of TA (in relative terms, therefore line with aux3/aux2)
    aux = numpy.ones((self.nBanks,self.nBanks))
    ii = int(0)
    aux2 = numpy.ones((self.nBanks,self.nBanks))
    for row in aux2:
      aux2[ii] = row*self.banks[ii].ta/10**9
      ii+=1
    aux3 = aux2.T
    
    self.bgsens_ia = aux
    self.bgsens_il = aux3/aux2
    
    return self.bgsens_il

  def mbgsensUtilBased(self):
    self.bgsens_ia = numpy.zeros((self.nBanks,self.nBanks))
    self.bgsens_il = numpy.zeros((self.nBanks,self.nBanks))
    for ii in range(0,self.nBanks):
      for jj in range(0,self.nBanks):
        xa0 = numpy.matrix(self.iapref_mat[:,ii]).T
        yl0 = numpy.matrix(self.ilpref_mat[jj,:]).T

        yl1 = numpy.copy(yl0)
        yl1[ii,0] = xa0[ii,0]
        
        xa1 = numpy.copy(xa0)
        xa1[jj,0] = yl0[jj,0]
        
        Ua0 = -(xa0.T*self.QQ*xa0)[0,0]+(xa0.T*self.RR)[0,0] #utility at optimum
        Ua1 = -(xa1.T*self.QQ*xa1)[0,0]+(xa1.T*self.RR)[0,0] #utility at optimum of the funding side
        
        Ul0 = (yl0.T*self.QQdef*yl0)[0,0] #utility at optimum
        Ul1 = (yl1.T*self.QQdef*yl1)[0,0] #utility at optimum of the funding side

        #   allocation
        #!!sensitivities are multiplicative, so differently presented as in the paper
        if abs(Ua1-Ua0)>self.BGUTILPRECISION:
          self.bgsens_ia[jj,ii] = max(0,abs(xa1[jj,0]-xa0[jj,0])/(Ua1-Ua0))
        if abs(Ul1-Ul0)>self.BGUTILPRECISION:
          self.bgsens_il[jj,ii] = max(0,abs(yl1[ii,0]-yl0[ii,0])/(Ul1-Ul0))
        self.bgutil_ia[jj,ii] = Ua0
        self.bgutil_il[jj,ii] = Ul0
  
  def mBargaingGame(self):
    #initialisation
    bg_mat = numpy.zeros((self.nBanks,self.nBanks))
    iamax_ua_mat = list()
    ilmax_ua_mat = list()
    for b in self.banks:
      iamax_ua_mat.append(b.iamax_ua)
      ilmax_ua_mat.append(b.ilmax_ua)
    iamax_ua_mat = numpy.matrix(iamax_ua_mat)
    ilmax_ua_mat = numpy.matrix(ilmax_ua_mat).T #mind transposition here
    
    iamax_ua_mat_2d = numpy.tile(iamax_ua_mat,(self.nBanks,1))
    ilmax_ua_mat_2d = numpy.tile(ilmax_ua_mat,(1,self.nBanks))

    #unused limit related to the LE
    limit_le_ua = numpy.array([[b.LExpLimitIndivRatio*b.ee]*self.nBanks for b in self.banks]).T - numpy.array([b.ia for b in self.banks]).T
    #print("min of limit_le_ua:")
    #print(numpy.min(limit_le_ua))

    #unused limit related to the allocated capital to the interbank business line
    limit_ei_ua = 1/(0.08)*numpy.array([[b.ei_ua/b.rw_ia_b]*self.nBanks for b in self.banks]).T

    #case 1
    ig0 = numpy.where(self.iapref_mat>self.ilpref_mat)
    xg = 0.5*(self.ilpref_mat+self.iapref_mat+self.bgsens_il*self.bgutil_il-self.bgsens_ia*self.bgutil_ia)
    bg_mat[ig0] = numpy.minimum(numpy.maximum(numpy.minimum(xg[ig0],self.iapref_mat[ig0]),self.ilpref_mat[ig0]),numpy.minimum(limit_ei_ua[ig0],limit_le_ua[ig0]))
    #print("limit >")
    #print(numpy.sum(limit_ei_ua[ig0]))

    #case 2
    il0 = numpy.where(self.iapref_mat<self.ilpref_mat)
    xl = 0.5*(self.ilpref_mat+self.iapref_mat+self.bgsens_ia*self.bgutil_ia-self.bgsens_il*self.bgutil_il)
    bg_mat[il0] = numpy.minimum(numpy.maximum(numpy.minimum(xl[il0],self.ilpref_mat[il0]),self.iapref_mat[il0]),numpy.minimum(limit_ei_ua[il0],limit_le_ua[il0]))
    #print("limit <")
    #print(numpy.sum(limit_ei_ua[il0]))

    #transformation
    bg_mat_trans_l = numpy.copy(bg_mat)

    bg_mat_sum_l = numpy.tile(numpy.sum(bg_mat,1),(self.nBanks,1)).T
    trans_l = numpy.select([bg_mat_sum_l>self.BGPRECISION,bg_mat_sum_l<=self.BGPRECISION],[numpy.minimum(1,ilmax_ua_mat_2d/bg_mat_sum_l),1])
    bg_mat_trans_l = bg_mat*trans_l

    bg_mat_sum_a = numpy.tile(numpy.sum(bg_mat,0),(self.nBanks,1))
    trans_a = numpy.select([bg_mat_sum_a>self.BGPRECISION,bg_mat_sum_a<=self.BGPRECISION],[numpy.minimum(1,iamax_ua_mat_2d/bg_mat_sum_a),1])
    bg_mat_trans_a = bg_mat*trans_a

    #new interbank loans
    d_ibank = numpy.minimum(bg_mat_trans_a,bg_mat_trans_l) 
    #new total increment of interbank assets and liabilities
    idg0 = numpy.where(d_ibank>1.0)
    d_ibank_a_sum = numpy.sum(d_ibank,0)
    d_ibank_l_sum = numpy.sum(d_ibank,1)

    #accrueing the interbank market
    self.iBankDepoMat+=d_ibank

    #print("ia pref:")
    #print(numpy.sum(self.iapref_mat))

    #print("il pref:")
    #print(numpy.sum(self.ilpref_mat))

    #print("raw bg_mat:")
    #print(numpy.sum(bg_mat))
    #print("increm:")
    #print(numpy.sum(d_ibank))

    #new total interbank assets and liabilities
    ii=int(0)
    for b in self.banks:      
      b.iamax_ua+= -d_ibank_a_sum[ii] 
      b.ilmax_ua+= -d_ibank_l_sum[ii]

      #transcribing to banks' individual ia and il lists
      b.ia = numpy.array(self.iBankDepoMat[:,ii].T)[0].tolist()
      b.il = numpy.array(self.iBankDepoMat[ii,:])[0].tolist()

      b.ei_ua+= -0.08*self.RW_IA[ii]*sum(b.ia)
      b.ei_ua = max(0.0,b.ei_ua) #in case of overshooting with b.ia
      
      ii+=1

  def mEndogNetsDiagnostics(self):
    maxia = [b.iamax for b in self.banks]
    ia_ratio_diag = numpy.sum(self.iBankDepoMat,0)/maxia

    maxil = [b.ilmax for b in self.banks]
    il_ratio_diag = numpy.sum(self.iBankDepoMat,1).T/maxil

    self.EndogNetsDiags = {'ia_ratio':ia_ratio_diag,'il_ratio':il_ratio_diag}

  def mNetworkXAnal(self):
    import networkx as nx

    self.IBGraph = nx.Graph()
    self.IBGraph.add_nodes_from(range(0,self.nBanks))

    self.IBGraphWght = nx.Graph()
    self.IBGraphWght.add_nodes_from(range(0,self.nBanks))

    edges_array=numpy.argwhere(self.iBankDepoMat>self.ADJPRECISION) #ADJPREC very small, just greater than 0
    edges_tpl = [tuple([tp[0,0],tp[0,1]]) for tp in edges_array]
    self.IBGraph.add_edges_from(edges_tpl)

    tpl_wght = list() #list of triples (3 element tuples), with last entry as weight
    for edgs in edges_array:
      tpl = tuple([edgs[0,0],edgs[0,1],self.iBankDepoMat[edgs[0,0],edgs[0,1]]])
      tpl_wght.append(tpl)
    self.IBGraphWght.add_weighted_edges_from(tpl_wght)

    #degree
    dgree = nx.degree_centrality(self.IBGraph)

    #betweenness
    bness = nx.betweenness_centrality(self.IBGraph)
    bness_wght = nx.betweenness_centrality(self.IBGraphWght,weight='weight')

    #closeness
    close = nx.closeness_centrality(self.IBGraph)

    #clustering coeff.
    clust = nx.clustering(self.IBGraph)

    #size of lending activity
    iba = numpy.sum(self.iBankDepoMat,0)
    
    #size of borrowing activity
    ibl = numpy.sum(self.iBankDepoMat,1)


    ## random graphs
    #expected degree:
    dgree_list = list()
    maxdeg = self.nBanks-1.0
    for ii in range(0,self.nBanks):
      dgree_list.append(int(dgree[ii]*maxdeg))
    print(dgree_list)

    IBGraph_expdeg = nx.expected_degree_graph(dgree_list)
    dgree_expdeg = nx.degree_centrality(IBGraph_expdeg)
    bness_expdeg = nx.betweenness_centrality(IBGraph_expdeg)
    clust_expdeg = nx.clustering(IBGraph_expdeg)

    #random clustered graph
    trngs = nx.triangles(self.IBGraph)
    trngs_norm = list()
    #inddg = {x: 0 for x in range(0,self.nBanks)}#independent degree sequence calculations (out: dictionary)
    inddg = dict((x, 0) for x in range(0,self.nBanks)) #modern version, typically required for v2.7+
    for ii in range(0,self.nBanks):
      trngs_norm.append(trngs[ii]/((self.nBanks-1.0)*(self.nBanks-2.0)/2.0))
      aux = int(0)
      nbrs = self.IBGraph.neighbors(ii)
      for ll in nbrs:
        nbrs_ii = self.IBGraph.neighbors(ll)
        if len(list(set(nbrs) & set(nbrs_ii)))==int(0):
          aux+=1
      inddg[ii] = aux
    print(inddg)
    
    deg_tri = list()
    for ii in range(0,self.nBanks):
      ll = list()
      ll.append(inddg[ii])
      ll.append(trngs[ii])
      deg_tri.append(ll)
    print(deg_tri)
    IBGraph_trngs = nx.random_clustered_graph(deg_tri)
    dgree_trngs = nx.degree_centrality(IBGraph_trngs)
    bness_trngs = nx.betweenness_centrality(IBGraph_trngs)
    clust_trngs = trngs_norm #nx.clustering(IBGraph_trngs)
    
    #collecting
    self.mEndogNetsDiagnostics()
    self.Measures_dict = {'Dgree':dgree, 'Bness':bness, 'Bness_wght':bness_wght, 'Close':close, 'Clust':clust, 'ia_ratio':self.EndogNetsDiags['ia_ratio'],'il_ratio':self.EndogNetsDiags['il_ratio'],'iba':iba,'ibl':ibl,'dgree_expdeg':dgree_expdeg,'bness_expdeg':bness_expdeg,'clust_expdeg':clust_expdeg,'dgree_trngs':dgree_trngs,'bness_trngs':bness_trngs,'clust_trngs':clust_trngs}


  def mPlotMe(self):
    import matplotlib.pyplot as pp
    listPos = list()
    for bb in self.banks:
      circBank = plt.Circle((bb.xx,bb.yy),radius=0.5)
      listPos.append(circBank)
      self.ax.add_artist(circBank)
    self.position = listPos
    plt.show()
    
  def mPlotIBank(self):
    mexp = 0
    for bb in self.banks:
      mexp = max(mexp,max(bb.ia))
    self.maxexposure = mexp
    
    listPos = list()
    for bb in self.banks:
      for lnk in bb.ia:
        if lnk>0:
          inx_link = bb.ia.index(lnk)
          v_aux = [bb.xx,bb.yy,self.banks[inx_link].xx-bb.xx,self.banks[inx_link].yy-bb.yy]
          
          #in order to avoid div0 - 2.0 is added
          xlength = 0.5*numpy.log(lnk+2.0)/numpy.log(self.maxexposure+2.0) 
          self.ax.arrow(v_aux[0],v_aux[1],v_aux[2],v_aux[3],width=xlength)
    plt.show()
  
  def mSaveResults(self):
    resfile = open("D:\\Doc\\Contagion\\python\\results.csv",'w',newline='',encoding='utf8')
    writeit = csv.writer(resfile,delimiter=';')
    writeit.writerow(["p_bar","p_ast"])
    for row in range(self.nBanks):
      writeit.writerow([self.p_bar[i,0],self.p_ast[i,0]])
    resfile.close()

  def mSaveMat2File(self,fpath,x):
    resfile = open(fpath,'w')
    writeit = csv.writer(resfile,delimiter=',')
    for row in x:
      writeit.writerow(row)
    resfile.close()
        
################################################################
####                      SIMULATIONS                       ####
################################################################

BankingSystem = list()
NB = 80 #number of banks
xangle = 2.0*numpy.pi/float(NB)

#bs data
## structure of the bs_trimmed.csv
# each row corresponds to a given bank in the sample
# 1 column: total assets
# 2 column: interbank assets
# 3 column: (not used)
# 4 column: (not used)
# 5 column: (not used)
# 6 column: total capital
# 7 column: (not used)
# 8 column: interbank liabilities
# 9 column: capital allocated to the interbank portfolio
#10 column: group member (non used in the simulations)


with open('D:\\Doc\\InterbankContagion\\python\\RTF\\bs_trimmed.csv','r') as net:
#with open('/home/ghalaj/Documents/BW2013/EndogNets/EndogNetsSeq/python/bs_trimmed.csv','r') as net:
  datareader = csv.reader(net)
  bs_data = []
  for row in datareader:
    l = list()
    for item in row:
      l.append(float(item))
    bs_data.append(l)


for i in range(0,NB):
  iarand = random.random()*100
  ilrand = random.random()*100
  
  xcoord = 50.0+49.0*numpy.sin(xangle*i)
  ycoord = 50.0+49.0*numpy.cos(xangle*i)
  #def __init__(self,nb,n,ta,loans,sec,iamax,depo,wf,ilmax,db,e,ei,xx,yy,bname,shortbname,cds,lgd,bsp):
  B1 = Banks(NB,i+1,bs_data[i][0],[],[],bs_data[i][1],[],[],bs_data[i][7],[],bs_data[i][5],bs_data[i][8],xcoord,ycoord,'bb',bs_data[i][9],0,0.40,numpy.zeros((27,1)))
  BankingSystem.append(B1)

IB = InterBank(BankingSystem)

# CREATION OF ENDOGENOUS NETWORKS
IB.mFormulateIBAssetPreferredStr()    #round 1: banks choose their preferred interbank exposures
IB.mFormulateIBLiabPreferredStr()     #round 2: banks choose their preferred interbank funding sources
IB.mbgsensUtilBased()                 #definition of the utility function for the bargaining game
IB.mBargaingGame()                    #round 3: Bargaining Game on the market for the interbank funding

IB.mNetworkXAnal()                    #post-simulation: analysis of the emerging network structures (NetworkX used)

#the structure of the network is kept in IB.iBankDepoMat!


