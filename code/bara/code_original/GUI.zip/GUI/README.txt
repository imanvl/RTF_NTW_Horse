BaralFique GUI - README file

BaralFique.m - Run this file to launch GUI
hybrid_fct2.m - main function that fits the marginals to a user defined copula family

All other files are auxiliary functions to these two. See ppt for instructions.